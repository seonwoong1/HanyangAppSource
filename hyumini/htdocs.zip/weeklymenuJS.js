﻿$(document).ready(function()
{
	//var no_hide_time = ".breakfast";
	//var no_hide_day = ".mon";
	
	$(".menu").hide();
	/*
	$(".breakfast").hide();
	$(".lunch").hide();
	$(".diner").hide();	
	
	//요일 클래스 이름
	//mon, tue, wed, thur, fri, sat, sun
	
	//$(".mon").hide();
	$(".tue").hide();
	$(".wed").hide();
	$(".thur").hide();
	$(".fri").hide();
	$(".sat").hide();
	$(".sun").hide();
	*/

    $(".studentResInfo").hide();
    $(".staffResInfo").hide();
    $(".FCInfo").hide();
    $(".DormResInfo").hide();
    $(".StartupResInfo").hide();

    $(".studentRes").click(function(){
        $(".studentResInfo").toggle();
    });
    $(".staffRes").click(function(){
        $(".staffResInfo").toggle();
    });
    $(".FC").click(function(){
        $(".FCInfo").toggle();
    });
    $(".DormRes").click(function(){
        $(".DormResInfo").toggle();
    });
    $(".StartupRes").click(function(){
        $(".StartupResInfo").toggle();
    });

	
	 $(".StartupRes").click(function(){
        $(".StartupResInfo").toggle();
    });
	
	
	
	var btn_mon, btn_tue, btn_wed, btn_thu, btn_fri, btn_sat, btn_sun;
	var btn_breakfast, btn_lunch, btn_dinner;
	
	
	btn_mon = document.getElementById("btn_mon");	
	btn_tue = document.getElementById("btn_tue");
	btn_wed = document.getElementById("btn_wed");
	btn_thu = document.getElementById("btn_thu");
	btn_fri = document.getElementById("btn_fri");
	btn_sat = document.getElementById("btn_sat");
	btn_sun = document.getElementById("btn_sun");
	
	btn_breakfast = document.getElementById("btn_breakfast");
	btn_lunch = document.getElementById("btn_lunch");
	btn_dinner = document.getElementById("btn_dinner");
	
	/*
	요일 클래스 이름
	mon, tue, wed, thur, fri, sat, sun
	*/	
	 //alert("버튼 클릭 전");
	//var isShown
	/*
	$(".btn").click(function(){
		
        //alert("버튼 클릭");
		
        $(".mon").show();
		$(".tue").hide();
		$(".wed").hide();
		$(".thur").hide();
		$(".fri").hide();
		$(".sat").hide();
		$(".sun").hide();
		
    });
	*/
	
  });
