$(document).ready(function(){
    $(".studentResInfo").hide();
    $(".staffResInfo").hide();
    $(".FCInfo").hide();
    $(".DormResInfo").hide();
    $(".StartupResInfo").hide();

    $(".studentRes").click(function(){
        $(".studentResInfo").toggle();
    });
    $(".staffRes").click(function(){
        $(".staffResInfo").toggle();
    });
    $(".FC").click(function(){
        $(".FCInfo").toggle();
    });
    $(".DormRes").click(function(){
        $(".DormResInfo").toggle();
    });
    $(".StartupRes").click(function(){
        $(".StartupResInfo").toggle();
    });

  });
