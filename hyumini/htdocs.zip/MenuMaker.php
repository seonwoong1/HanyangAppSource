<?php
	include "WeeklyMenuGetter.php";

	
	
	$format_index_string ='<P>%d, %d</P>';

  
	for ($time_index=0; $time_index<3; $time_index++)
	{	
		$time = get_time_by_i($time_index);
		for ($day_index = 0; $day_index < 7; $day_index++)
		{
			$day_of_week = get_day_of_week_by_j($day_index);
			$string = sprintf($format_index_string, $time_index, $day_index);
			echo $string;
			
			
			echo "<div class = \"menu $time $day_of_week\">";
			echo "<p>$time\t$day_of_week</p>";
			
			// �������Ĵ�, �л��Ĵ�, �����Ĵ�, Ǫ����Ʈ, â���������� ������
			// 0,1,2,3,4
			
			show_menu_in_time("Student Restaurant", "studentRes", "studentResInfo", $menu[1][$time_index], $price[1][$time_index], $day_index);
			show_menu_in_time("Staff Restaurant", "staffRes", "staffResInfo", $menu[0][$time_index], $price[0][$time_index], $day_index);
			
			show_foodcourt_menu($menu[3], $price[3], $day_index);
			
			show_menu_in_time("Dorm Restaurant", "DormRes", "DormResInfo", $menu[2][$time_index], $price[2][$time_index], $day_index);
			show_menu_in_time("Startup Incubation Center", "StartupRes", "StartupResInfo", $menu[4][$time_index], $price[4][$time_index], $day_index);
			
			echo "</div>";
		}
	}
	
	
	function show_foodcourt_menu($menu, $price, $day_index)
	{
		//, $menu[3][$time_index], $price[3][0], $day_index
		$size = count($menu[0]);
		echo "size ��: $size </BR>\n";
		if ($size <= 1 || $menu[0][0][$day_index] =="")
		{			
			return;
		}
	
		$string = "
			<div>
				<button type=\"button\" class=\"btn btn-info restaurant FC\">Food Court</button>
				<div class=\"alert alert-info FCInfo\" role=\"alert\">
					<nav>
					  <ul class=\"pager\">
						<li class = \"btn_korean\">Korean </li>
						<li class = \"btn_western\">Western </li>
						<li class = \"btn_snack\">Snack </li>
					  </ul>
					</nav>
					<div class=\"alert alert-danger menuList\" role=\"alert\">	";
		echo $string;
		
			
		
		$kind = array("korean", "western", "snack");
		for ($kind_index = 0; $kind_index < count($kind); $kind_index++)
		{
			echo 		"<div class=\"{$kind[$kind_index]}\" role=\"alert\">";
			for ($item_index = 0; $item_index < $size; $item_index++)
			{
				$string = $menu[$kind_index][$item_index][$day_index];
				if ($string !="")
				{
					echo 	"<p>{$string}</p>";
				}
			}
			echo 		"</div>";
		}
		
		
				  
		$string = '		  
					</div>
					<div class="alert alert-danger menuCost" role="alert">
				';
		echo $string;		
		
		
		
		for ($kind_index = 0; $kind_index < count($kind); $kind_index++)
		{
			echo 		"<div class=\"{$kind[$kind_index]}\" role=\"alert\">";
			for ($item_index = 0; $item_index < $size; $item_index++)
			{
				$string = $price[$kind_index][$item_index][$day_index];
				if ($string !="")
				{
					echo 	"<p>{$string}</p>";
				}
			}
			echo 		"</div>";
		}
		
		$string = '		  
					</div>
				</div>
			</div>			
			';
		echo $string;	
	}
	
	
	
	
	function show_menu_in_time($restraunt_title, $button_class, $menu_class, $menu_in_time, $price_in_time, $day_index)
	{
		$size = count($menu_in_time);
		echo "size ��: $size </BR>\n";
		if ($size <= 1 || $menu_in_time[0][$day_index] =="")
		{			
			return;	
		}
	
		$string = "
			<div>
				<button type=\"button\" class=\"btn btn-info restaurant $button_class\">$restraunt_title</button>
			  <div class=\"alert alert-info $menu_class\" role=\"alert\">
				<div class=\"alert alert-danger menuList\" role=\"alert\">
				";
		echo $string;	
		
		for ($k = 0; $k < $size; $k++)
		{
			$string = $menu_in_time[$k][$day_index];
			if ($string !="")
			{
				echo "<p>{$string}</p>";
			}
		}		
				  
		$string = '		  
				</div>
				<div class="alert alert-danger menuCost" role="alert">
				';
		echo $string;
		
		$size = count($price_in_time);
		//echo "<p>$size</p>";
		for ($k = 0; $k < count($price_in_time); $k++)
		{
			$string = $price_in_time[$k][$day_index];
			if ($string !="")
			{
				echo "<p>{$string}</p>";
			}
		}
		
		$string = '		  
				</div>
			  </div>
			</div>			
			';
		echo $string;
	}
	
	
	// �Ʒ� �� function �� html���� class �� �����ϱ� ���ؼ� ��
	// class �� �����ϴ� ����: �ڹ� ��ũ��Ʈ���� hide �� ���� ����
	function get_time_by_i($i)
	{
		switch($i)
		{
		case 0:
			return "breakfast";
		case 1:
			return "lunch";
		case 2:
			return "diner";
		default:
			return "";
		}
	}
	
	
	function get_day_of_week_by_j($j)
	{
		switch($j)
		{
		case 0:
			return "mon";
		case 1:
			return "tue";
		case 2:
			return "wed";
		case 3:
			return "thur";
		case 4:
			return "fri";
		case 5:
			return "sat";
		case 6:
			return "sun";
		}
	}

?>