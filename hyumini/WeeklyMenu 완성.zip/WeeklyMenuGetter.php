﻿<?php
	// curl is an extension that needs to be installed,
	// php.ini 에서 이 부분 수정 ;extension=php_curl.dll
	
	
	
	$breakfast = "아침식사";	
	
	
	$location 		= array();
	$time_foodcourt = array();
	$time_breakfast = array();
	$time_lunch		= array();
	$time_diner		= array();
	/*
	점심과 저녁을 합쳐놓은 2차원 배열,
	기숙사 식당의 경우는 아침, 점심, 저녁 순서의 2차원 배열
	배열에서 앞쪽 인덱스가 아침, 점심, 저녁,
	뒤 인덱스가 월, 화, 수, 목, 금에 해당함.	
	*/	
	$menu		= array();
	$price		= array();
	
	/*
	$lunch		= array();
	$diner		= array();
	$lunch_price= array();
	$diner_price= array();
	*/
	

	/* URL에서 restId 가 있는데, 1,2,3,4,5 가 각각 
	   교직원, 학생, 창업보육센터, 푸드코트, 창의인재원식당을 의미한다.
	*/
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_FAILONERROR, true);
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	
	
	for ($i = 0; $i < 5; $i++)
	{		
		$id = $i+1;
		curl_setopt($curl, CURLOPT_URL, "https://m.hanyang.ac.kr/wlife/diet/diet001002.page?campusId=02&restId=0$id&apiUrl%5B%5D=%2FDHSH%2FA201300004.json");
		
		//echo "https://m.hanyang.ac.kr/wlife/diet/diet001002.page?campusId=02&restId=0$id&apiUrl%5B%5D=%2FDHSH%2FA201300004.json";
		
		$result = curl_exec($curl);	
		
		$result = preg_replace("#</div>#", ";", $result);		
		
		
		$result = preg_replace("#\<(/?[^\>]+)\>#", "\n", $result);
		$result = preg_replace("#\|+#", "\n", $result);		
		$result = preg_replace("#\|\s\|#", "\n", $result);
		$result = preg_replace("#[[:space:]]{2,}#", "\n", $result);
		
		$result = preg_replace("#;#", "|", $result);
		
		$result = preg_replace("#&nbsp\|#", ";", $result);		
		
/*
		if ($i != 2)
			continue;			
		echo $result;
		*/
		
		$pattern = "/위치.+/";
		preg_match($pattern, $result, $matches);
		$location[$i] = $matches[0];
		
		// 교직원식당, 학생식당, 기숙사식당, 푸드코트, 창업보육센터 순서로
			// 0,1,2,3,4
		
		if ($i != 3 )
		{		
		
			$time_breakfast[$i] = get_full_time_by_time("조식", $result);
			$time_lunch[$i] = get_full_time_by_time("중식", $result);
			$time_diner[$i] = get_full_time_by_time("석식", $result);
			
			//echo 'i값: '.$i.'중식: '.$time_lunch[$i].'</br>';
			
			get_menu_in_time("조식", 0, $result, $i);
			get_menu_in_time("중식", 1, $result, $i);
			get_menu_in_time("석식", 2, $result, $i);
			
			
		}
		else
		{
		/*
			if ($restraunt_index==3){
				echo "푸드코트</br>";
			}
			*/
		
			$time_foodcourt = get_foodcourt_time();
			get_menu_in_time("한식", 0, $result, $i);
			get_menu_in_time("양식", 1, $result, $i);
			get_menu_in_time("분식", 2, $result, $i);
		/*
			get_menu_in_time("한식", 3, $result, $i);
			get_menu_in_time("양식", 4, $result, $i);
			get_menu_in_time("분식", 5, $result, $i);
		*/	
		}
		
	}
	
	function get_foodcourt_time()
	{
		$pattern = "/위치.+\\n\|\\n(.*?)/";
		preg_match($pattern, $result, $matches);
		return $matches[1];
	}
	
	
	function get_full_time_by_time($str_time, $source)
	{
		//$pattern = "/{$str_time}([^\|]){1,50}\|/";
		$pattern = "/{$str_time}(.{1,50})/";
		preg_match($pattern, $source, $matches);
		
		$string = $matches[1];		
		if ($string !="")
		{
			$source = $string;
			//return $source;	
		}
		
		$pattern = "#[0-9]{2}:[0-9]{2}( )?~( )?[0-9]{2}:[0-9]{2}#";
		preg_match($pattern, $source, $matches);
		return $matches[0];
	}
	
	
	function get_menu_in_time($str_time, $time_index, $source, $restraunt_index)
	{	
		global $menu, $price;		
		
		
		$pattern = "#$str_time\\n\|\\n([^|]+)\|#";
		preg_match_all($pattern, $source, $matches);		
		
		if (restraunt_index==3){
		//echo "regex 패턴: $pattern</br>";
		//echo "원본</BR> $source</br>";
		//echo "matches: {$matches[1][0]}</br>";
		}
		
		
		$matches_size = count($matches);
		//echo "<p>matches_size: $matches_size</p>";
		
		// $j 는 각 요일의 각 시간당 몇 번째 메뉴인지와 연결됨		
		for ($day_index = 0; $day_index < 7; $day_index++)		
		//for ($day_index = 0; $day_index < 1; $day_index++)
		{		
			$string = $matches[1][$day_index];
			$word = explode("\n", $string);
			$menu_index = 0;
			//echo 'count($word) 값:'.count($word).'</br>';
			for ($item_index = 0; $item_index < count($word); $item_index++)
			{				
				$string = $word[$item_index];
				
				
				if ( is_price($string) )
				{
					$price[$restraunt_index][$time_index][$menu_index][$day_index] = $string;
					$menu_index++;
					/*
					if ($restraunt_index==3 && $day_index == 3)
					{
						echo '$string 값:'.$string.'</br>';
						echo '$restraunt_index 값:'.$restraunt_index.'</br>';
						echo '$time_index 값:'.$time_index.'</br>';
						echo '$menu_index 값:'.$menu_index.'</br>';
						echo '$day_index 값:'.$day_index.'</br>';
					}
*/					
				}
				else if ( $string == ";" )
				{
					$menu_index++;										
				}
				else
				{
					$prev_value = $menu[$restraunt_index][$time_index][$menu_index][$day_index];
					if ($prev_value == "")
					{									
						$menu[$restraunt_index][$time_index][$menu_index][$day_index] = $string;
						/*
						if ($restraunt_index==3 && $day_index == 3)
						{
							echo '$string 값:'.$string.'</br>';
							echo '$restraunt_index 값:'.$restraunt_index.'</br>';
							echo '$time_index 값:'.$time_index.'</br>';
							echo '$menu_index 값:'.$menu_index.'</br>';
							echo '$day_index 값:'.$day_index.'</br>';
						}
						*/
					}
					else
					{
						$menu[$restraunt_index][$time_index][$menu_index][$day_index] =
							$prev_value." ".$string;						
					}
				}
			}
		}			
	}
	
	function is_price($string)
	{
	
		//echo "발견한 한 줄: ".$string."</br>";
		$pattern = "/^([0-9]+,)?[0-9]+$/";
		preg_match($pattern, $string, $matches);
		//echo "matches[0]: ".$matches[0]."</br>";
		if ($matches[0] != "")
		{
			//echo "수 발견함</br>";
			return true;
		}	
		else
			return false;
	}
	
	curl_close($curl);
	
  ?>