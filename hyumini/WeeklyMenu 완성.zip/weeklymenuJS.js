﻿$(document).ready(function()
{
	//var no_hide_time = ".breakfast";
	//var no_hide_day = ".mon";
	
	$(".menu").hide();
	/*
	$(".breakfast").hide();
	$(".lunch").hide();
	$(".diner").hide();	
	
	//요일 클래스 이름
	//mon, tue, wed, thur, fri, sat, sun
	
	//$(".mon").hide();
	$(".tue").hide();
	$(".wed").hide();
	$(".thur").hide();
	$(".fri").hide();
	$(".sat").hide();
	$(".sun").hide();
	*/

    $(".studentResInfo").hide();
    $(".staffResInfo").hide();
    $(".FCInfo").hide();
    $(".DormResInfo").hide();
    $(".StartupResInfo").hide();

    $(".studentRes").click(function(){
        $(".studentResInfo").toggle();
    });
    $(".staffRes").click(function(){
        $(".staffResInfo").toggle();
    });
    $(".FC").click(function(){
        $(".FCInfo").toggle();
    });
    $(".DormRes").click(function(){
        $(".DormResInfo").toggle();
    });
    $(".StartupRes").click(function(){
        $(".StartupResInfo").toggle();
    });

	
	 $(".StartupRes").click(function(){
        $(".StartupResInfo").toggle();
    });
	
	
	
	var timeShowArray = new Array(3);
	var dayShowArray = new Array(7);
	
	var foodcourtShowArray = new Array(3);
	
	
	set_array_control_buttons(timeShowArray, "time");
	set_array_control_buttons(dayShowArray, "day");
	set_array_control_buttons(foodcourtShowArray, "foodcourt");
	
	function set_array_control_buttons(array, string)
	{	
		for ( var i = 0; i < array.length; i++ )
		{
			array[i] = false;
			
			$(".btn_"+string+"_"+i).click
			(
				function ()
				{
					var string = this.getAttribute("class");
					var value = string.charAt(string.length - 1);
					set_array_values(array, value);
					show_and_hide_contents();
					show_and_hide_foodcourt_contents();
				}
			);			
		}		
	}
	
	
	function set_array_values(array, i)
	{		
		for ( var j = 0; j < array.length; j++ )
		{
			if ( i == j )
			{
				array[j] = true;
			}
			else
			{
				array[j] = false;
				//alert("i값: "+i);
			}
		}
	}
	
	
	// 요일과 시간 값이 모두 true인 경우만 보여주고,
	// 나머지는 감춤
	function show_and_hide_contents()
	{
		for ( var i = 0; i < timeShowArray.length; i++ )
		{
			for ( var j = 0; j < dayShowArray.length; j++ )
			{
				if ( (timeShowArray[i] == true) && (dayShowArray[j] == true) )
				{
					$(".menu"+i+j).show();
					//$(".menu"+i+j).show();
					//alert("보여줘야 하는 것: .menu"+i+j);
				}
				else
				{
					//$(".menu"+i+j).show();
					$(".menu"+i+j).hide();
					//$(".menu"+i+j).show();
				}				
			}		
		}
	}
	
	
	
	function show_and_hide_foodcourt_contents()
	{
		for ( var i = 0; i < foodcourtShowArray.length; i++ )
		{
			if ( foodcourtShowArray[i] == true)
			{
				$(".foodcourt"+i).show();
			}
			else
			{
				$(".foodcourt"+i).hide();
			}		
		}
	}
	
	
  });
